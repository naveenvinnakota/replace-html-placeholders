# Script used to read Property File
if [ $# == 3 ]; then

IN_FILE=$1
PROPS_FILE=$2
OUT_FILE=$3

if [ -f "$3" ]; then
rm "$3"
fi

if [ -f "$1" -a -f "$2" ]; then


while read LINE
do

      check=`echo $LINE | grep "\[\["`
      if [ $? == 0 ]; then

	occur=`echo $LINE | grep -o "\[\[" | wc -l`
	
	for ((i=1; i<=$occur; i++));
	do

	        key=`echo $LINE | sed 's/.*\[\[\([^]]*\)\]\].*/\1/g'`

		if [ "$key" != "$LINE" ]; then
			value=`cat $PROPS_FILE | grep "^$key" | cut -d'=' -f2`
			mline=`echo $LINE | sed "s/\[\[${key}\]\]/${value}/g"`				
 			LINE=$mline			
		fi
		
	done ##end of for
	echo $LINE >> $OUT_FILE
	
      else
 	echo $LINE >> $OUT_FILE	
      fi

done < $IN_FILE

fi
else
 echo "usage: ./replaceTokens.sh [input html file] [properties file] [output html file]"
fi
